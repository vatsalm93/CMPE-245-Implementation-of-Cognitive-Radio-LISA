/*
===============================================================================
 Name        : Hello_world.c
 Author      :
 Version     : 1
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include <cr_section_macros.h>
#include <math.h>
#include "myLisa.h"
#include "gpio.h"


#define TX_MODE		1
#define RX_MODE		2
#define TIMER_VAL 	 0.5
#define ORDER 		 7
#define DELAY_100_MS 50
#define DELAY2       60000

#define LED_GREEN_PORT	3
#define LED_GREEN_PIN	25

#define DATA_TX_RX_PORT	0
#define TX_PIN		3
#define RX_PIN 	    2

void delay(uint32_t count)
{
	LPC_TIM0->TCR = 0x02;
	LPC_TIM0->PR = 0x00;
	LPC_TIM0->MR0 = count* TIMER_VAL *(9000000 / 1000-1);
	LPC_TIM0->IR = 0xff;
	LPC_TIM0->MCR = 0x04;
	LPC_TIM0->TCR = 0x01;
	while (LPC_TIM0->TCR & 0x01);
	return;
}

void transmit_data(uint8_t* transmit_data, int length)
{
    GPIOinitOut(DATA_TX_RX_PORT, TX_PIN);
	clearGPIO(DATA_TX_RX_PORT, TX_PIN);

    for(int i = 0; i < length; i++)
   	{
   		if(transmit_data[i] == 0x01)
   		{
   			setGPIO(LED_GREEN_PORT,LED_GREEN_PIN);
   			setGPIO(DATA_TX_RX_PORT, TX_PIN);
   			delay(DELAY_100_MS);
   		}
   		else
   		{
   			clearGPIO(LED_GREEN_PORT,LED_GREEN_PIN);
   			clearGPIO(DATA_TX_RX_PORT, TX_PIN);
   			delay(DELAY_100_MS);
   		}
  /*  	if (i % 16 == 0)
    	{
   			printf("\n");
    	}
   		//printf("%u ",transmit_data[i]);*/
   	}

	clearGPIO(DATA_TX_RX_PORT, TX_PIN);
}

char recvd_data[512];
char flag = 0;
int packet_len = 0;
void receive_data(int length)
{
	GPIOinitOut(DATA_TX_RX_PORT, RX_PIN);
	setGPIO(DATA_TX_RX_PORT, RX_PIN);
    GPIOinitIn(DATA_TX_RX_PORT, RX_PIN);

    int i =0;
   	if(LPC_GPIO0->FIOPIN & (1 << RX_PIN))
   	{
   		flag = 1;
   		for( i = 0; i < length; i++)
   		{
   			if(LPC_GPIO0->FIOPIN & (1 << RX_PIN))
   			{
   				recvd_data[i] = '1';
   			}
   			else {
   				recvd_data[i] = '0';
   			}
   			packet_len++;
   			delay(DELAY_100_MS);
   		}
   	}
}

packet_s P;

int main(void)
{
    volatile static int input_mode = 0 ;

	GPIOinitOut(LED_GREEN_PORT,LED_GREEN_PIN);
    create_data_packet(&P);
    convert_data_packet(&P);

	while(1)
    {
    	printf("\n\nEnter a command to activate TX(1) & RX(2): \n");
        scanf("%d", &input_mode);

		if(input_mode == TX_MODE)
		{
			transmit_data(tx_data,sizeof(packet_s)*8);
		}


#if 0
		if(flag== 1) {
		//	print_buffer(recvd_data,packet_len);
			reconvert_data_packet(recvd_data,packet_len);
		    //check_confidence_and_ret_payload(&P, payload_data); //Check confidence level based on corrupted packets from the data
			packet_len = 0;
			flag = 0;
		}



        int corruptedBits = 0;

        uint8_t *file_data = (uint8_t*)malloc(BUFFER_SIZE *sizeof(uint8_t));
        memcpy(file_data, arbitrary_data, BUFFER_SIZE);

        create_data_file(file_data);  //Create a data file with 2k of Arbitrary data
        printf("\n------File Data w/o Sync Code------\n");
        print_file_data();

        srand(time(NULL));   //Find a random offset using rand() to write a Packet info to the File
        uint32_t offset = rand() % (BUFFER_SIZE - sizeof(packet_s));
        printf("\n\nOffset = %x|%d\n", offset, offset);

        memcpy(file_data + offset, &P, sizeof(packet_s)); //Write data to a file with sync code
        create_data_file(file_data);
        printf("\n------File Data w/ Sync Code------\n");
        print_file_data();
#endif
    }
    return 0;
}
