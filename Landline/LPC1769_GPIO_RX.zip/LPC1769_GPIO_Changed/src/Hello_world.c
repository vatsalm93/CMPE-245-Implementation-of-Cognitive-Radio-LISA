/*
===============================================================================
 Name        : Hello_world.c
 Author      : Vidushi jain
 Version     : 1
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include <cr_section_macros.h>
#include <math.h>
#include "myLisa.h"
#include "gpio.h"


#define TX_MODE		1
#define RX_MODE		2
#define TIMER_VAL 	 0.5
#define ORDER 		 7
#define DELAY_100_MS 50
#define DELAY2       60000

#define LED_GREEN_PORT	3
#define LED_GREEN_PIN	25

#define DATA_TX_RX_PORT	0
#define TX_PIN		2//2
#define RX_PIN 		3//3

packet_s P;

void delay(uint32_t count)
{
	LPC_TIM0->TCR = 0x02;
	LPC_TIM0->PR = 0x00;
	LPC_TIM0->MR0 = count* TIMER_VAL *(9000000 / 1000-1);
	LPC_TIM0->IR = 0xff;
	LPC_TIM0->MCR = 0x04;
	LPC_TIM0->TCR = 0x01;
	while (LPC_TIM0->TCR & 0x01);
	return;
}

void transmit_data(uint8_t* transmit_data, int length)
{
    GPIOinitOut(DATA_TX_RX_PORT, TX_PIN);
	clearGPIO(DATA_TX_RX_PORT, TX_PIN);

    for(int i = 0; i < length; i++)
   	{
   		if(transmit_data[i] == 0x01)
   		{
   			setGPIO(LED_GREEN_PORT,LED_GREEN_PIN);
   			setGPIO(DATA_TX_RX_PORT, TX_PIN);
   			delay(DELAY_100_MS);
   		}
   		else
   		{
   			clearGPIO(LED_GREEN_PORT,LED_GREEN_PIN);
   			clearGPIO(DATA_TX_RX_PORT, TX_PIN);
   			delay(DELAY_100_MS);
   		}
  /*  	if (i % 16 == 0)
    	{
   			printf("\n");
    	}
   		printf("%u ",transmit_data[i]);*/
   	}

	clearGPIO(DATA_TX_RX_PORT, TX_PIN);
}

void receive_data(int length)
{
	GPIOinitOut(DATA_TX_RX_PORT, RX_PIN);
	setGPIO(DATA_TX_RX_PORT, RX_PIN);
    GPIOinitIn(DATA_TX_RX_PORT, RX_PIN);

   	if(LPC_GPIO0->FIOPIN & (1 << RX_PIN))
   	{
   		data_received = 1;
   		for(int i = 0; i < length; i++)
   		{
   			if(LPC_GPIO0->FIOPIN & (1 << RX_PIN))
   			{
   				received_data[i] = '1';
   			}
   			else {
   				received_data[i] = '0';
   			}
   			total_data_received += 1;
   			delay(DELAY_100_MS);
   		}
   	}
}

int main(void)
{
    volatile static int input_mode = 0 ;

	GPIOinitOut(LED_GREEN_PORT,LED_GREEN_PIN);
    create_data_packet(&P);
  //  convert_data_packet(&P);

	while(1)
    {
	/*	printf("\n\nEnter a command to activate TX(1) & RX(2): \n");
		        scanf("%d", &input_mode);

				if(input_mode == TX_MODE)
				{
					transmit_data(tx_data,sizeof(packet_s)*8);
				}
				else if(input_mode == RX_MODE)
				{
					receive_data(sizeof(packet_s)*8);
				}*/
		receive_data(sizeof(packet_s)*8);
		if(data_received == 1) {
			reconvert_data_packet(received_data,total_data_received);
		    check_confidence_and_ret_payload(&P,data_len);
			memset(payload_data,0,data_len);
		    total_data_received = 0;
			data_received = 0;
			data_len = 0;
		}

    }
    return 0;
}
